// Header definition to only perform once
#ifndef HEADER_H
#define HEADER_H
#include <vector>
#include <map>
using namespace std;

// Function declarations used
void ReadFile(vector<string>& itemList);
void WriteFile(map<string, int>& itemMap);
void VectorToMap(vector<string>& itemList, map<string, int>& itemMap);
void DisplayMenu();
void MenuInput(int menuOption, map<string, int>& itemMap);
void MenuOption1(map<string, int>& itemMap);
void MenuOption2(map<string, int>& itemMap);
void MenuOption3(map<string, int>& itemMap);

#endif 

