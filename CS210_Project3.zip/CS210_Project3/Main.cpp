#include <iostream>
#include <fstream>
#include <iomanip>
#include "Header.h"
#include <string>
#include <vector>
#include <map>
using namespace std;

// Main
int main() {
	// Initialize vector, map, and menu selection variables
	vector<string> productList;
	map<string, int> productMap;
	int menuChoice;

	// Call read file, vector to map, and write file functions
	ReadFile(productList);
	VectorToMap(productList, productMap);
	WriteFile(productMap);

	// Loop through first time
	do {
		// Call display menu function and get menu selection input
		DisplayMenu();
		cout << "Select an option" << endl;
		cin >> menuChoice;
		// Call menu input function
		MenuInput(menuChoice, productMap);
	} while (menuChoice != 4); // Exit if menuChoice is equal to 4

	// Program exit message
	cout << endl;
	cout << "See you again!" << endl;

	return 0;
}