#include <iostream>
#include <fstream>
#include <iomanip>
#include "Header.h"
#include <string>
#include <vector>
#include <map>
using namespace std;

// Function to read file contents
void ReadFile(vector<string>& itemList) {
	// Initialize input file stream, file name + value strings, and loop bool
	ifstream itemFS;
	string fileName;
	string fileValue;
	bool fileOpen = false;
	
	// While loop bool is false
	while (!fileOpen) {
		// Get file name to open and attempt to open
		cout << "Enter file name to open" << endl;
		cin >> fileName;
		itemFS.open(fileName);

		// If file cannot be opened, print message and continue loop 
		if (!itemFS.is_open()) {
			cout << "Coud not open " << fileName << " - input different file" << endl;
		}
		// Else set loop bool to true and exit loop
		else {
			fileOpen = true;
		}
	}
	
	// Scan file for first value
	itemFS >> fileValue;
	// While scan is valid, loop
	while (!itemFS.fail()) {
		// Append itemList vector with scanned value, then scan again
		itemList.push_back(fileValue);
		itemFS >> fileValue;
	}
	// Close file
	itemFS.close();
}

// Function to open and write file
void WriteFile(map<string, int>& itemMap) {
	// Initialize output file stream
	ofstream outFS;
	
	// Open the appropriate file
	outFS.open("frequency.dat");
	// If cannot be opened, print message
	if (!outFS.is_open()) {
		cout << "Could not open file frequency.dat" << endl;
	}
	// Else loop through itemMap and print key, value pair to file
	else {
		for (const auto& pair : itemMap) {
			outFS << pair.first << ": " << pair.second << endl;
		}
	}
	// Close file
	outFS.close();
}

// Function to translate vector to map
void VectorToMap(vector<string>& itemList, map<string, int>& itemMap) {
	// Loop through all vector elements
	for (string element : itemList) {
		// If it cannot be found in itemMap, insert unique string
		if (itemMap.find(element) == itemMap.end()) {
			itemMap.insert(make_pair(element, 0));
		}
	}
	// Loop through all map pairs
	for (auto& pair : itemMap) {
		// Set count to default (0)
		int count = 0;
		// Loop through all vector elements
		for (string element : itemList) {
			// If map key is equal to vector element, increment count
			if (pair.first == element) {
				count++;
			}
		}
		// Set map pair value as count for appropriate key
		pair.second = count;
	}
}


// Function to display mentu
void DisplayMenu() {
	//Set string for formatting
	string filler(10, '_');
	string menuHeader = "Select A Menu Option";
	string filler2(2 * size(filler) + size(menuHeader), '-');
	// Print menu with the 4 options
	cout << filler << "Select A Menu Option" << filler << endl;
	cout << "[1] - User Item/Word Search" << endl;
	cout << "[2] - File Frequency Summary" << endl;
	cout << "[3] - File Frequency Summary Histogram" << endl;
	cout << "[4] - Exit Program" << endl;
	cout << filler2 << endl;
	cout << endl;
}

// Function to handle menu selection
void MenuInput(int menuOption, map<string, int>& itemMap) {
	// Set loop bool to default (false)
	bool loopExit = false;

	// While loop bool is false, loop
	while (!loopExit) {
		// Switch case representing menu options
		switch (menuOption) {
		case 1:
			// Call option 1 function, set loop bool to true, and break
			MenuOption1(itemMap);
			loopExit = true;
			break;
		case 2:
			// Call option 2 function, set loop bool to true, and break
			MenuOption2(itemMap);
			loopExit = true;
			break;
		case 3:
			// Call option 3 function, set loop bool to true, and break
			MenuOption3(itemMap);
			loopExit = true;
			break;
		case 4:
			// Print message, set loop bool to true, and break
			cout << "Program exited" << endl;
			loopExit = true;
			break;
		default:
			// Print message and continue loop
			cout << "Invalid input - try again" << endl;
			continue;
		}
	}
}

// Function to search for specific product
void MenuOption1(map<string, int>& itemMap) {
	// Set loop bool to default (false) and initialize string input
	bool searchFound = false;
	string searchInput;
	// Get string input
	cout << "Please enter a word or item" << endl;
	cin >> searchInput;
	// For input size, upper case first letter and lower case all other letters (to compare to itemMap keys)
	for (int i = 0; i < searchInput.size(); i++) {
		if (i == 0) {
			searchInput.at(i) = toupper(searchInput.at(i));
		}
		else {
			searchInput.at(i) = tolower(searchInput.at(i));
		}
	}
	// For itemMap key, value pairs
	for (const auto& pair : itemMap) {
		// If key matches searchInput, print frequency and set loop bool to true
		if (pair.first == searchInput) {
			cout << "Product found - frequency: " << pair.second << endl;
			cout << "Returning to menu" << endl;
			searchFound = true;
		}
	}
	// If not found, print message
	if (!searchFound) {
		cout << "No such product found - heading back to menu" << endl;
	}
}

// Function to print product frequency summary
void MenuOption2(map<string, int>& itemMap) {
	cout << endl;
	cout << "File Frequency Summary" << endl;
	// Loop through and print all key, value pairs in itemMap 
	for (const auto& pair : itemMap) {
		cout << pair.first << ": " << pair.second << endl;
	}
	cout << "Returning to menu" << endl;
	cout << endl;
}

// Function to print product frequency summary histogram
void MenuOption3(map<string, int>& itemMap) {
	cout << endl;
	string headerTitle = "File Frequency Summary Histogram";
	cout << headerTitle << endl;
	// Loop through key, value pairs in itemMap
	for (const auto& pair : itemMap) {
		// Format to align histogram based on headerTitle size
		cout << left << setw(headerTitle.size()) << pair.first << ": ";
		// For value size, output equal amount of symbols
		for (int i = 0; i < pair.second; i++) {
			cout << "[-]";
		}
		cout << endl;
	}
	cout << "Returning to menu" << endl;
	cout << endl;
}
